from django.urls import path

from budget import views

urlpatterns=[
    path('',views.main,name="main"),
    path('reg',views.reg,name="reg"),
    path('addofficer',views.addofficer,name="addofficer"),
    path('addwork', views.addwork, name="addwork"),
    path('addmanageofficer', views.addmanageofficer, name="addmanageofficer"),
    path('addmanagework', views.addmanagework, name="addmanagework"),
    path('homepage', views.homepage, name="homepage"),
    path('sentnotification', views.sentnotification, name="sentnotification"),
    path('verifycontractor', views.verifycontractor, name="verifycontractor"),
    path('viewreport', views.viewreport, name="viewreport"),
    path('viewworkstatus', views.viewworkstatus, name="viewworkstatus"),
    path('addreport', views.addreport, name="addreport"),
    path('homecontractor', views.homecontractor, name="homecontractor"),
    path('reports', views.reports, name="reports"),
    path('request', views.request, name="request"),
    path('homepage', views.homepage, name="homepage"),
    path('update', views.update, name="update"),
    path('updateworkstatus', views.updateworkstatus, name="updateworkstatus"),
    path('viewinstruction', views.viewinstruction, name="viewinstruction"),
    path('viewnotification', views.viewnotification, name="viewnotification"),
    path('viewworkrqst', views.viewworkrqst, name="viewworkrqst"),
    path('homeofficer', views.homeofficer, name="homeofficer"),
    path('viewcontractor', views.viewcontractor, name="viewcontractor"),
    path('viewofficernoti', views.viewofficernoti, name="viewofficernoti"),
    path('viewofficerreport', views.viewofficerreport, name="viewofficerreport"),
    path('instruction', views.instruction, name="instruction"),
    path('viewstatus', views.viewstatus, name="viewstatus"),
    path('regcode', views.regcode, name="regcode"),
    path('logincode', views.logincode, name="logincode"),
    path('officercode', views.officercode, name="officercode"),
    path('viewrqstverify', views.viewrqstverify, name="viewrqstverify"),
    path('workcode', views.workcode, name="workcode"),
    path('rejectcontractor/<int:id>', views.rejectcontractor, name="rejectcontractor"),
    path('verifycontractor1/<int:id>', views.verifycontractor1, name="verifycontractor1"),
    path('notifications', views.notifications, name="notifications"),
    path('notisent', views.notisent, name="notisent"),
    path('workrqst', views.workrqst, name="workrqst"),
    path('workreject', views.workreject, name="workreject"),



































]