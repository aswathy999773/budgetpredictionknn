from django.http import HttpResponse
from django.shortcuts import render
from datetime import datetime
# Create your views here.
from budget.models import *


def main(request):
    return render(request,'login.html')

def reg(request):
    return render(request,'register.html')

def addofficer(request):
    return render(request,'admin/add officer.html')

def addwork(request):
    return render(request,'admin/add work.html')

def addmanageofficer(request):
    ob = officer.objects.all()
    return render(request,'admin/add_manage oficer.html',{'val':ob})

def addmanagework(request):
    ob = work.objects.all()
    return render(request,'admin/add_manage work.html',{'val':ob})

def homepage(request):
    return render(request,'admin/homepge.html')

def sentnotification(request):
    ob = notification.objects.all()
    return render(request,'admin/sent notification.html',{'val':ob})

def verifycontractor(request):
    ob = contractor.objects.all()
    return render(request,'admin/verify contractor.html',{'val':ob})

def viewreport(request):
    ob=report.objects.all()
    return render(request,'admin/view report.html',{'val':ob})

def viewrqstverify(request):
    ob = request.objects.filter(lid__type='date')
    return render(request,'admin/view rqst&verify.html')

def viewworkstatus(request):
    ob = contractor.objects.filter(lid__type='contractor')
    return render(request,'admin/view work status.html',{'val':ob})

def addreport(request):
    return render(request,'contractor/Add report.html')

def homecontractor(request):
    return render(request,'contractor/homecontractor.html')

def reports(request):
    return render(request,'contractor/report.html')

def request(request):
    return render(request,'contractor/request.html')

def update(request):
    return render(request,'contractor/update.html')

def updateworkstatus(request):
    return render(request,'contractor/update work status.html')

def viewinstruction(request):
    return render(request,'contractor/view instruction.html')

def viewnotification(request):
    return render(request,'contractor/view notification.html')

def viewworkrqst(request):
    return render(request,'contractor/view work and rqst.html')

def homeofficer(request):
    return render(request,'officer/homeofficer.html')

def viewcontractor(request):
    return render(request,'officer/view contractor.html')

def viewofficernoti(request):
    return render(request,'officer/view notification.html')

def viewofficerreport(request):
    return render(request,'officer/view report.html')

def instruction(request):
    return render(request,'officer/instruction.html')

def viewstatus(request):
    return render(request,'officer/view work status.html')

def verifycontractor1(request,id):
    ob=login.objects.get(id=id)
    ob.type='contractor'
    ob.save()
    return HttpResponse('''<script>alert("accepted");window.location='/verifycontractor'</script>''')

def rejectcontractor(request):
    ob = login.objects.get(id=id)
    ob.type = 'reject'
    ob.save()
    return HttpResponse('''<script>alert("rejected");window.location='/verifycontractor'</script>''')

def workrqst(request):
    ob = request.objects.get(id=id)
    ob.satus = 'work'
    ob.save()
    return HttpResponse('''<script>alert("accepted");window.location='/viewrqstverify'</script>''')

def workreject(request):
    ob = request.objects.get(id=id)
    ob.satus = 'work'
    ob.save()
    return HttpResponse('''<script>alert("rejected");window.location='/viewrqstverify'</script>''')





def regcode(request):
    fname=request.POST['textfield']
    lname=request.POST['textfield2']
    place=request.POST['textfield3']
    postoffice= request.POST['textfield4']
    pin= request.POST['textfield5']
    email = request.POST['textfield6']
    phoneno = request.POST['textfield7']
    username= request.POST['textfield8']
    password=request.POST['textfield9']
    district=request.POST['textfield10']
    ob=login()
    ob.username=username
    ob.password=password
    ob.type='pending'
    ob.save()
    iob=contractor()
    iob.fname=fname
    iob.lname=lname
    iob.place=place
    iob.postoffice=postoffice
    iob.pin=pin
    iob.email=email
    iob.phoneno=phoneno
    iob.username=username
    iob.password=password
    iob.district=district
    iob.lid=ob
    iob.save()
    return HttpResponse('''<script>alert("registered");window.location='/'</script>''')

def logincode(request):
    username=request.POST['textfield']
    password=request.POST['textfield2']
    # try:
    ob=login.objects.get(username=username,password=password)
    if ob.type == 'admin':
        return HttpResponse('''<script>alert("welcome");window.location='/homepage'</script>''')
    elif ob.type == 'contractor':
        return HttpResponse('''<script>alert("welcome");window.location='/homecontractor'</script>''')
    elif ob.type == 'officer':
        return HttpResponse('''<script>alert("welcome");window.location='/homeofficer'</script>''')
    else:
        return HttpResponse('''<script>alert("invalid");window.location='/'</script>''')
    # except:
    #     return HttpResponse('''<script>alert("invalid");window.location='/'</script>''')



def officercode(request):
    fname=request.POST['fname']
    lname=request.POST['lname']
    place=request.POST['place']
    postoffice=request.POST['post']
    district=request.POST['district']
    phoneno=request.POST['phone']
    email=request.POST['email']
    username=request.POST['uname']
    password=request.POST['pw']
    pin=request.POST['pin']
    ob = login()
    ob.username = username
    ob.password = password
    ob.type = 'officer'
    ob.save()
    iob = officer()
    iob.fname = fname
    iob.lname = lname
    iob.place = place
    iob.postoffice = postoffice
    iob.email = email
    iob.phoneno = phoneno
    iob.username = username
    iob.password = password
    iob.district = district
    iob.pin = pin
    iob.lid = ob
    iob.save()
    return HttpResponse('''<script>alert("addofficer");window.location='/'</script>''')

def workcode(request):
    works = request.POST['textfield']
    descriptions= request.POST['textfield2']
    type = request.POST['textfield3']
    iob= work()
    iob.work=works
    iob.type=type
    iob.description=descriptions
    iob.date=datetime.today()
    iob.save()
    return HttpResponse('''<script>alert("addofficer");window.location='/homepage'</script>''')

def notisent(request):
    return render(request,'admin/snt noti.html')



def notifications(request):
    notifications=request.POST['textfield']

    iob= notification()
    iob.notification=notifications
    iob.date=datetime.today()
    iob.save()
    return HttpResponse('''<script>alert("ok");window.location='/sentnotification'</script>''')




